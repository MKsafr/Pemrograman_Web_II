<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #222222;
        }
        .container {
            width: 500px;
            max-width: 400px;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        .container h2 {
            font-size: 35px;
            margin-bottom: 20px;
            color: #333;
        }
        .container form {
            width: 100%;
        }
        .container form .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        .container form .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #666;
        }
        .container form .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .container form .form-group input:focus {
            border-color: #007bff;
            outline: none;
        }
        .container form .form-group .invalid-feedback {
            color: red;
            font-size: 12px;
            display: none;
        }
        .container form .form-group .alert {
            color: #856404;
            background-color: #fff3cd;
            border-color: #ffeeba;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: left;
        }
        .container form .btn {
            width: 48%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            box-sizing: border-box;
            margin-top: 10px;
        }
        .container form .btn-primary {
            background-color: #007bff;
        }
        .container form .btn-primary:hover {
            background-color: #0056b3;
        }
        .container form .btn-secondary {
            background-color: #dc3545;
        }
        .container form .btn-secondary:hover {
            background-color: #c82333;
        }
        .container .footer {
            margin-top: 20px;
            color: #999;
        }
    </style>
    <script>
        function validateForm() {
            var isValid = true;

            var judul = document.getElementById('judul');
            var judulFeedback = judul.nextElementSibling;
            if (judul.value.trim() === '') {
                judulFeedback.style.display = 'block';
                isValid = false;
            } else {
                judulFeedback.style.display = 'none';
            }

            var penulis = document.getElementById('penulis');
            var penulisFeedback = penulis.nextElementSibling;
            if (penulis.value.trim() === '') {
                penulisFeedback.style.display = 'block';
                isValid = false;
            } else {
                penulisFeedback.style.display = 'none';
            }

            var penerbit = document.getElementById('penerbit');
            var penerbitFeedback = penerbit.nextElementSibling;
            if (penerbit.value.trim() === '') {
                penerbitFeedback.style.display = 'block';
                isValid = false;
            } else {
                penerbitFeedback.style.display = 'none';
            }

            var tahun_terbit = document.getElementById('tahun_terbit');
            var tahun_terbitFeedback = tahun_terbit.nextElementSibling;
            if (tahun_terbit.value.trim() === '') {
                tahun_terbitFeedback.style.display = 'block';
                isValid = false;
            } else {
                tahun_terbitFeedback.style.display = 'none';
            }
            return isValid;
        }
    </script>
</head>

<body>
    <div class="container">
        <?php if(session()->getFlashdata('pesan')): ?>
            <div class="alert" role="alert">
                <?= session()->getFlashdata('pesan') ?>
            </div>
        <?php endif?>

        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert" role="alert">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif?>
        <h2>Tambah Data Buku</h2>
        <form action="<?= base_url('/tambahdata') ?>" method="post" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="judul">Judul</label>
                <input type="text" id="judul" name="judul">
                <div class="invalid-feedback">Judul is required</div>
            </div>
            <div class="form-group">
                <label for="penulis">Penulis</label>
                <input type="text" id="penulis" name="penulis">
                <div class="invalid-feedback">Penulis is required</div>
            </div>
            <div class="form-group">
                <label for="penerbit">Penerbit</label>
                <input type="text" id="penerbit" name="penerbit">
                <div class="invalid-feedback">Penerbit is required</div>
            </div>
            <div class="form-group">
                <label for="tahun_terbit">Tahun Terbit</label>
                <input type="text" id="tahun_terbit" name="tahun_terbit">
                <div class="invalid-feedback">Tahun Terbit is required</div>
            </div>
            <button type="submit" class="btn btn-primary">Tambah</button>
            <a href="<?= base_url('/') ?>" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
