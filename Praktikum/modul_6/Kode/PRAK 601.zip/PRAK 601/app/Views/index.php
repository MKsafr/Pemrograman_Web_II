<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            display: flex;
            background-color: #222222;
        }
        .sidebar {
            width: 250px;
            background-color: #007bff;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 20px;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            position: relative;
            height: 100%;
        }

        .logout-btn {
            margin-bottom: 20px;
        }

        .sidebar h2 {
            margin: 0;
            font-size: 24px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            margin: 10px 0;
            width: 70%;
            text-align: center;
            border-radius: 5px;
        }
        .sidebar a:hover {
            background-color: #c82333;
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .content h1 {
            font-size: 35px;
            margin-bottom: 20px;
            color: #fff;
        }
        .content h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #fff;
        }
        .table-container {
            margin-top: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            background-color: #dddddd;
            padding: 10px;
            border: 2px solid #ccc;
            text-align: left;
        }
        .table th {
            background-color: #007bff;
            color: white;
        }
        .btn {
            padding: 10px 50px;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-success {
            background-color: #28a745;
            transition: background-color 0.3s;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .btn-warning {
            background-color: #ffc107;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-sm {
            padding: 5px 10px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Menu</h2>
        <a href="<?= base_url('/logout')?>" class="btn btn-danger logout-btn">Logout</a>
    </div>

    <div class="content">
        <div>
            <h1>Selamat Datang di database Perpustakan</h1>
        </div>
        <div class="table-container">
            <h2>Daftar Buku</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun Terbit</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($data as $row): ?>
                        <tr>
                            <td><?= $row['judul'] ?></td>
                            <td><?= $row['penulis'] ?></td>
                            <td><?= $row['penerbit'] ?></td>
                            <td><?= $row['tahun_terbit'] ?></td>
                            <td>
                                <a href="<?= base_url('/editdata/'.$row['id']) ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form action="<?= base_url('/hapusdata/'.$row['id'])?>" style="display:inline" method="post">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('Apakah anda yakin?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
            <a class="btn btn-success" href="<?= base_url('/tambahdata')?>">Tambah Data</a>
        </div>
    </div>
</body>
</html>
