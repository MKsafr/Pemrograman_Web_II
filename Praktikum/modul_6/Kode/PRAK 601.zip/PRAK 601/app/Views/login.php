<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<style>
		body, html {
			height: 100%;
			margin: 0;
			font-family: Arial, Helvetica, sans-serif;
			display: flex;
			justify-content: center;
			align-items: center;
			background-color: #222222;
		}
		.container {
			width: 500px;
			max-width: 400px;
			background-color: white;
			padding: 20px;
			border-radius: 10px;
			text-align: center;
		}
		.container h1 {
			font-size: 35px;
			margin-bottom: 20px;
			color: #333;
		}
		.container form {
			width: 100%;
		}
		.container form .form-group {
			margin-bottom: 15px;
			text-align: left;
		}
		.container form .form-group label {
			display: block;
			margin-bottom: 5px;
			color: #666;
		}
		.container form .form-group input {
			width: 100%;
			padding: 10px;
			border: 1px solid #ccc;
			border-radius: 5px;
			box-sizing: border-box;
		}
		.container form .form-group input:focus {
			border-color: #007bff;
			outline: none;
		}
		.container form .form-group .invalid-feedback {
			color: red;
			font-size: 12px;
			display: none;
		}
		.container form .form-group .alert {
			color: #856404;
			background-color: #fff3cd;
			border-color: #ffeeba;
			padding: 10px;
			border-radius: 5px;
			margin-bottom: 15px;
			text-align: left;
		}
		.container form .btn {
			width: 100%;
			padding: 10px;
			border: none;
			border-radius: 5px;
			background-color: #007bff;
			color: white;
			font-size: 16px;
			cursor: pointer;
			box-sizing: border-box;
		}
		.container form .btn:hover {
			background-color: #0056b3;
		}
		.container .footer {
			margin-top: 20px;
			color: #999;
		}
	</style>
	<script>
		function validateForm() {
			var isValid = true;

			var username = document.getElementById('username');
			var usernameFeedback = username.nextElementSibling;
			if (username.value.trim() === '') {
				usernameFeedback.style.display = 'block';
				isValid = false;
			} else {
				usernameFeedback.style.display = 'none';
			}

			var email = document.getElementById('email');
			var emailFeedback = email.nextElementSibling;
			var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
			if (!emailPattern.test(email.value)) {
				emailFeedback.style.display = 'block';
				isValid = false;
			} else {
				emailFeedback.style.display = 'none';
			}

			var password = document.getElementById('password');
			var passwordFeedback = password.nextElementSibling;
			if (password.value.trim() === '') {
				passwordFeedback.style.display = 'block';
				isValid = false;
			} else {
				passwordFeedback.style.display = 'none';
			}

			return isValid;
		}
	</script>
</head>
<body>
	<div class="container">
		<?php if(session() -> getFlashdata('pesan')): ?>
			<div class="alert" role="alert">
				<?= session()->getFlashdata('pesan') ?>
			</div>
		<?php endif?>

		<?php if(session() -> getFlashdata('error')): ?>
			<div class="alert" role="alert">
				<?= session()->getFlashdata('error') ?>
			</div>
		<?php endif?>
		<h1>Perpustakaan Online</h1>
		<h2>Login</h2>
		<form action="<?= base_url('/login')?>" method="POST" class="needs-validation" novalidate="" autocomplete="off" onsubmit="return validateForm()">
			<div class="form-group">
				<label for="username">User Name</label>
				<input id="username" type="text" name="username" required>
				<div class="invalid-feedback">Username is required</div>
			</div>
			<div class="form-group">
				<label for="email">E-Mail Address</label>
				<input id="email" type="email" name="email" value="" required autofocus>
				<div class="invalid-feedback">Email is invalid</div>
			</div>
			<div class="form-group">
				<label for="password">Password</label>
				<input id="password" type="password" name="password" required>
				<div class="invalid-feedback">Password is required</div>
			</div>
			<button type="submit" class="btn">Login</button>
		</form>
	</div>
</body>
</html>
